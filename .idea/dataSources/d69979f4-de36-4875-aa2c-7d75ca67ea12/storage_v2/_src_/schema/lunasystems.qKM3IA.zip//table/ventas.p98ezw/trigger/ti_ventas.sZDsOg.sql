create definer = lunasystems@localhost trigger ti_ventas
    after insert
    on ventas
    for each row
BEGIN
declare _id_documento int;

set _id_documento = new.id_documento;

update documentos_empresa as de 
set de.numero = de.numero + 1 
where de.id_documento  =_id_documento;

END;

