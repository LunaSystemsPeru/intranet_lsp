create definer = root_lsp@`%` trigger td_ventas_cobros
    after delete
    on ventas_cobros
    for each row
BEGIN
declare _id_venta int;
declare _monto float;
declare _idmovimiento int;

set _id_venta = old.id_venta;
set _monto = old.monto;
set _idmovimiento = old.id_movimiento;

update ventas as v 
set v.monto_pagado = v.monto_pagado - _monto, v.estado = 1
where v.id_venta = _id_venta;

delete from bancos_movimientos
where bancos_movimientos.id_movimiento = _idmovimiento;

END;

