create definer = root@localhost trigger ti_bancos
  after INSERT
  on bancos_movimientos
  for each row
BEGIN
declare _monto float;
declare _id_banco int;

set _id_banco = new.id_banco;
set _monto = new.ingresa - new.sale;

update caja_bancos as b 
set b.monto = b.monto + _monto 
where b.id_banco = _id_banco;

END;

