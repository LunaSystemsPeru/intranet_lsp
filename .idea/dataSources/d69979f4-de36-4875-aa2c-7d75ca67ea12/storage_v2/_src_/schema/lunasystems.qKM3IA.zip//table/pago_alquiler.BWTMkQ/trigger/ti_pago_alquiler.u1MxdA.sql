create definer = lunasystems@localhost trigger ti_pago_alquiler
    after insert
    on pago_alquiler
    for each row
BEGIN

declare _id_alquiler int;
declare _nueva_fecha_pago date;
declare _fecha_pago date;

set _id_alquiler = new.id_producto_alquiler;
set _fecha_pago = new.fecha;

update producto_alquiler as pa 
set pa.fecha_pago = _fecha_pago, pa.fecha_siguiente_pago = date_add(_fecha_pago, interval 1 year) 
where pa.id_producto_alquiler = _id_alquiler;

END;

