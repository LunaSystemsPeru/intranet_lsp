create definer = lunasystems@localhost trigger td_orden_interna
    before delete
    on orden_interna
    for each row
BEGIN
declare _id_cotizacion int;

set _id_cotizacion = old.id_cotizacion;

update cotizaciones as c set c.estado = 0 where c.id_cotizacion = _id_cotizacion;
END;

