create definer = lunasystems@localhost trigger ti_pagos_frecuente_pago
    after insert
    on pagos_frecuente_pago
    for each row
BEGIN
declare _idfrecuente int;
declare _idmovimiento int;
declare _monto float;
declare _totalpago float;

set _idfrecuente = new.id_frecuente;
set _idmovimiento = new.id_movimiento;

select bm.sale
into _monto 
from bancos_movimientos as bm 
where bm.id_movimiento = _idmovimiento;

select pf.monto 
into _totalpago
from pagos_frecuentes as pf
where pf.id_frecuente = _idfrecuente;

update pagos_frecuentes as pf
set pf.pagado = pf.pagado + _monto
where pf.id_frecuente = _idfrecuente;

update pagos_frecuentes as pf 
set pf.fecha_recordatorio = date_add(pf.fecha_recordatorio, INTERVAL 1 month), pf.pagado = 0 
where pf.id_frecuente = _idfrecuente and pf.monto = pf.pagado;
END;

