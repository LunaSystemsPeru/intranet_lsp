create definer = root@localhost trigger ti_ventas_cobros
  after INSERT
  on ventas_cobros
  for each row
BEGIN
declare _id_venta int;
declare _monto float;

set _id_venta = new.id_venta;
set _monto = new.monto;

update ventas as v 
set v.monto_pagado = v.monto_pagado + _monto 
where v.id_venta = _id_venta;

UPDATE ventas as v 
set v.estado = 2 
where v.id_venta = _id_venta and v.monto_total = v.monto_pagado;

END;

