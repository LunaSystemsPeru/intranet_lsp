create definer = lunasystems@localhost trigger ti_orden_interna
    after insert
    on orden_interna
    for each row
BEGIN
declare _id_cotizacion int;

set _id_cotizacion = new.id_cotizacion;

update cotizaciones as c set c.estado = 1 where c.id_cotizacion = _id_cotizacion;
END;

