create definer = lunasystems@localhost trigger ti_orden_ventas
    after insert
    on orden_interna_ventas
    for each row
BEGIN
declare _id_orden int;
declare _id_venta int;
declare _monto float;

set _id_orden = new.id_orden_interna;
set _id_venta = new.id_venta;

select ventas.monto_total into _monto from ventas where ventas.id_venta = _id_venta;

update orden_interna set orden_interna.monto_facturado = monto_facturado + _monto where orden_interna.id_orden_interna = _id_orden;
END;

