create definer = lunasystems@localhost trigger ti_contratos_pagos
    after insert
    on contratos_pagos
    for each row
BEGIN
declare _idcontrato int;
declare _idmovimiento int;
declare _monto float;

set _idcontrato = new.id_contrato;
set _idmovimiento = new.id_movimiento;

select bm.sale 
into _monto 
from bancos_movimientos as bm
where bm.id_movimiento = _idmovimiento;

update contratos as c 
set c.monto_pagado = c.monto_pagado + _monto
where c.id_contrato = _idcontrato;

END;

